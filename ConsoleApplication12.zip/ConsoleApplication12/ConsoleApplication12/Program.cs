﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//nullable types

//give an int a value of 0
//choice represents 0 undecided, 1 yes 2 no
class Program
{
   //if the info is missing allow field to be null to show it's undefined

   public static void Main(string[] args)
   {
      int? q = 0;
      Console.WriteLine("Do you like pizza? Pick 1 for yes, 2 for no");
      q = Convert.ToInt16(Console.ReadLine());
      if (q == 1)
      {
         Console.WriteLine("I like pizza too!");
      }
      if (q == 2)
      {
         Console.WriteLine("That's too bad.");
            
      }
      
      else if (q < 1 | q > 1)
      {
         q = null;
         Console.Write("You'll have to come back to that question later.");

       }
      Console.ReadLine();
      }
         
   }
  

