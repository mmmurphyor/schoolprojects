﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//nullable types

class Program
{
    
    public static void Main(string[] args)
    {
        bool loop = true;
        while (loop == true)
            {
            int? q;   //nullable q is a value type, value type stored on heap, default to zero, making it nullable would let it have a null value
            //like if something being brought in from a database had a null value be able to be assigned to a value type.

            Console.WriteLine("Do you like pizza? Pick 1 for yes, 2 for no");
            q = Convert.ToInt16(Console.ReadLine());
            if (q == 1)
            {
                Console.WriteLine("I like pizza too!");
            }
            if (q == 2)
            {
                Console.WriteLine("That's too bad.");
            }
            else
            {
                string error = "That wasn't a valid response. Press any key to redo."; //string is a reference type, default value is null. Stored on the stack.
                loop = true;
                q = null;

                Console.WriteLine(error);

            }

            Console.ReadLine();
        }


    }

}
  

