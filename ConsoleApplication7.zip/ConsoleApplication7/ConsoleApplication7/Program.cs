﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

interface ITest
{
   //properties
   string FirstName { get; set; }
   string LastName { get; set; } 
}
class Test: ITest
{
   //fields
   private string _firstName;
   private string _lastName;
   //constructor
   public Test(string firstName, string lastName)
   {
      _firstName = firstName;
      _firstName = firstName;
   }
   //properties implemented
   public string FirstName
   {
      get
      {
         return _firstName;
      }
      set
      {
         _firstName = value;
      }
   }
   public string LastName
   {
      get
      {
         return _lastName;
      }
      set
      {
         _lastName = value;
      }
   }
}
   class Program
   {
      static void Print(ITest name)
   {
      Console.WriteLine(name.FirstName, name.LastName);
   }
      static void Main(string[] args)
      {
      Test name = new Test("Margret", "Murphy");
      Console.WriteLine("My name is ");   //stupid question. I want Print(name) to print on same line as
      Print(name);                        //My name is    I can't move it into Console.WriteLine, get error
      Console.ReadLine();                 //can't convert from void to object error. I've tried finding a way to 
      }                                  // do this, but I'm not even sure how to ask the question properly.
   }
