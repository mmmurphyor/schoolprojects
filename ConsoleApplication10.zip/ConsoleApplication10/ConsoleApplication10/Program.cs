﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//multicast delegate
public class MyName
{
   delegate void ShowName();

   public void FirstName()
   {
      Console.Write("My name is Margret ");
   }
   public void MiddleName()
   {
      Console.Write("Ann ");
   }

   public void LastName()
   {
      Console.WriteLine("Murphy.");
   }

   public static void Main(string[] args)
   { 
      MyName name = new MyName();

      //instantiate
      MyName.ShowName first = new MyName.ShowName(name.FirstName);
      MyName.ShowName middle = new MyName.ShowName(name.MiddleName);
      MyName.ShowName last = new MyName.ShowName(name.LastName);

      first();
      middle();
      last();
      Console.WriteLine();
      Console.WriteLine("I still have no idea what this is used for.");
      Console.ReadKey();
   }
}