﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//protected and protected internal (yup, stupid example)

class Name
{
    internal string fName;
    internal protected string lName;

    public void Print()
    {
        Console.Write("\nMy name is {0} {1}", fName, lName);
    }
}


class Program
{
    static void Main(string[] args)
    {
        Name myName = new Name();
        Console.Write("Enter your first name: ");
        myName.fName = Console.ReadLine();
        Console.Write("Enter your last name: ");
        myName.lName = Console.ReadLine();
        myName.Print();

        Console.ReadLine();
    }
}
