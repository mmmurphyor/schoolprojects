﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//exception handling
//exception handling log file

class Program
{
    //divide by zero error example

    static void Main(string[] args)
    {
        bool loop = true;
        do
        {
            try
            {
                Int32 numerator = 0;
                Int32 denominator = 0;
               

                Console.WriteLine("Enter numerator", numerator);
                numerator = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter denominator", denominator);
                denominator = Convert.ToInt32(Console.ReadLine());
                int answer = (numerator / denominator);
                
                Console.WriteLine("{0} divided by {1} is {2}", numerator, denominator, answer);

                loop = false;
            }
            catch (DivideByZeroException divideByZeroException)
            {
                Console.WriteLine("You tried to divide by zero.", divideByZeroException.Message);
               
                System.IO.File.WriteAllText(@"c:\error\error.txt", Convert.ToString(divideByZeroException));
            }
        } while (loop);
        Console.ReadLine();
    }
    
}



