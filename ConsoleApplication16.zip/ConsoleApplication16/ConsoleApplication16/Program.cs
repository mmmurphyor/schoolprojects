﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    private const string file = "c:/users/margret/test.bin";
    [Serializable]
    public abstract class Label
    {
        private string lblName;

        public virtual string LblName { get; set; }

        public virtual string Format()
        {
            return ("Formatting instructions go here");
        }
    }

    [Serializable]
    public class Mailing : Label
    {


        public override string Format()
        {
            return ("Mailing label formatting instructions go here");
        }
    }

    static void Main(string[] args)
    {
        Mailing lbl1 = new Mailing();
        Console.WriteLine(lbl1.Format());

        //to serialize
        IFormatter formatter = new BinaryFormatter();
        Stream writeStream = new FileStream(file, FileMode.Create, FileAccess.Write, FileShare.None);
        formatter.Serialize(writeStream, lbl1);
        writeStream.Close();

        //do deserialize
        Stream readStream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.None);
        Mailing lbl2 = (Mailing) formatter.Deserialize(readStream);
        Console.WriteLine();
        Console.WriteLine("This is what is read back: {0} same, same.", lbl2);
        
        Console.ReadKey();
    }
}



