﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//margret murphy
//c# item 23
//delegate example

delegate double myDelegate(double num1, double num2); //I had these as x and y but the examples I looked at didn't use these again...
//not getting the numbers to output. I'm trying to get whatever is the value of x and y to run through
//the appropriate method and then print the results. 

class Program
{
   static double number = 0;

   public static double Add(double x, double y)
   {
      double number = x + y;
      return number;
   }
   public static double Subtract(double x, double y)
   {
      double number = x - y;
      return number;
   }
   public static double Multiply(double x, double y)
   {
      double number = x * y;
      return number;
   }
   public static double Divide(double x, double y)
   {
      double number = x / y;
      return number;
   }
  public static double getNumber()
   {
      return number;
   }
   static void Main(string[] args)
   {
      myDelegate add, sub, mult, div;

      add = new myDelegate(Add);
      sub = new myDelegate(Subtract);
      mult = new myDelegate(Multiply);
      div = new myDelegate(Divide);

      add(25, 7);
      Console.WriteLine("Invoking delegate Add:", getNumber());
      sub(18, 4);
      Console.WriteLine("Invoking delegate Subtract:", getNumber());
      mult(12.4, 39);
      Console.WriteLine("Invoking delegate Multiply:", getNumber());
      div(.863, 14);
      Console.WriteLine("Invoking delegate Divide:", getNumber());

      Console.ReadLine();

   }
}

