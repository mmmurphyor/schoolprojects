namespace EntityFrameworkCF
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1() //constructor
            : base("name=Model1")
        {
        }

        public virtual DbSet<Book> Books { get; set; }
        public virtual DbSet<Table> Tables { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Book>()
                .Property(e => e.name)
                .IsFixedLength();

            modelBuilder.Entity<Book>()
                .Property(e => e.ISBN)
                .IsFixedLength();

            modelBuilder.Entity<Book>()
                .Property(e => e.price)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Table>()
                .Property(e => e.name)
                .IsFixedLength();

            modelBuilder.Entity<Table>()
                .Property(e => e.ISBN)
                .IsFixedLength();

            modelBuilder.Entity<Table>()
                .Property(e => e.price)
                .HasPrecision(19, 4);
        }
    }
}
