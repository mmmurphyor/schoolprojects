﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//item 39, option 1
namespace EntityFrameworkCF
{
    class Program
    {
        //create database
        static void Main(string[] args)
        {
            using (var db = new Model1())
            {
                Console.Write("Enter book name ");
                var name = Console.ReadLine();
                Console.Write("Enter an ISBN number ");
                var isbn = Console.ReadLine();
                Console.Write("Enter a price ");
                var price = Convert.ToDecimal(Console.ReadLine());
                
                //add books
                var book = new Book { name = name, ISBN = isbn, price = price};
                db.Books.Add(book);
                db.SaveChanges();

                //query to select books for display
                var query = from b in db.Books
                            orderby b.name, b.ISBN, b.price
                            select b;

                Console.WriteLine("All books in database: ");
                foreach(var item in query)
                {
                    Console.WriteLine(item.name, item.ISBN);
                }
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }
        }
    }
}
