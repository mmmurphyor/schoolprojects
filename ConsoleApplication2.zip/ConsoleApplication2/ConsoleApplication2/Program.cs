﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace ConsoleApplication2
{
    class Transfer
    {
        static void Main(string[] args)
        {
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string LogFolder = @"c:\Log";
            try
            {
                string DatabaseName = "booklist2";
                string SQLServerName = "(LocalDB)\\MSSQLLocalDB";
                String TableName = @"Book";
                String SchemaName = @"dbo";
                string fullFilePath = @"c:\users\margret\documents\booklist.xlsx";
                string sheetName = "Sheet1";

                SqlConnection SQLConnection = new SqlConnection();
                SQLConnection.ConnectionString = "Data Source = "
                    + SQLServerName + "; Initial Catalog = "
                    + DatabaseName + "; "
                    + "Integrated Security = true";

                string ConStr;
                string HDR;
                HDR = "YES";
                ConStr = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = "
                    + fullFilePath + "; Extended Properties =\"Excel 12.0; HDR = "
                    + HDR + ";IMEX = 0\"";
                OleDbConnection Conn = new OleDbConnection(ConStr);
                Conn.Open();
                OleDbCommand oconn = new OleDbCommand("select * from [" + sheetName + "$]", Conn);
                OleDbDataAdapter adp = new OleDbDataAdapter(oconn);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                Conn.Close();

                SQLConnection.Open();
                using (SqlBulkCopy BC = new SqlBulkCopy(SQLConnection))
                {
                    BC.DestinationTableName = SchemaName + "." + TableName;
                    foreach (var column in dt.Columns)
      //first try   // BC.ColumnMappings.Add(column.ToString(), column.ToString());
      //second try  // BC.ColumnMappings.Add(1, "ID:");
                    // BC.ColumnMappings.Add(2, "Name:");
                    //BC.ColumnMappings.Add(3, "ISBN:");
                    // BC.ColumnMappings.Add(4, "Price:");

                    BC.WriteToServer(dt); 
                }
                SQLConnection.Close();
            }
            catch (Exception exception)
            {
                using (StreamWriter sw = File.CreateText(LogFolder
                    + "\\" + "ErrorLog_" + datetime + ".log"))
                {
                    sw.WriteLine(exception.ToString());
                }
            }

            
        }
    }
}
