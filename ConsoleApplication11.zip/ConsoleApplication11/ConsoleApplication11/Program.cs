﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//enum
public class Winner
{
   enum Prize
   {
      First, 
      Second, 
      Third,
      Lost
   };
   static void Main(string[] args)
   {
      Prize value = Prize.First;
      int numValue = Convert.ToInt16(Prize.First);
      if (value == Prize.First)
      {
         Console.WriteLine("You won first place!");
         Console.WriteLine();
         Console.Write("Just for fun, the int value of First is: "+ numValue);
         Console.ReadLine();
      }
   }
}