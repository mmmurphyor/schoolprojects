﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//use of this
class Program
{
    public class Account
    {
        string name;
        int acctNum;

       
        public Account(string name, int acctNum)
        {
           this.name = name;
            this.acctNum = acctNum;
        }

        public void DisplayAcct()
        {
            Console.WriteLine("Name: ", name);
            Console.WriteLine("AcctNum: ");           
        }

        static void Main(string[] args)
        {
            string name;
            int acctNum;
            
            Console.WriteLine("Enter your name: ");
            name = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter your account number: ");
            acctNum = Convert.ToInt32(Console.ReadLine());

            Console.ReadKey();
        }
    }
}