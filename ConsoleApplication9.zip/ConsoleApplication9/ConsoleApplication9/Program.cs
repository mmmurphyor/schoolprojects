﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Calculation
{
   delegate void Calc(double x, double y);
   
   static void Add(double x, double y)
   {
      Console.Write("Invoking delegate Add: " + (x + y).ToString());
   }
   //static void Sub(double x, double y)
   //{
   //   Console.Write("Invoking delegate Sub: " + (x - y).ToString());
   //}
   static void Main(string[]args)
   {
      Calc addNumber = Add;
      addNumber.Invoke(25, 7);

     // Calc subNumber = Sub;
      //subNumber.Invoke(38.1-3);

      Console.ReadKey();
   }
}

