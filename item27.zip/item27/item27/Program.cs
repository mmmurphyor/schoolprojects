﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class item27
{

    public static void FileCheck(string source, string destination)
    {
        string[] sourcePath = null;// @"c:\users\margret\desktop\customer\";
        string[] destPath = null; //@"c:\users\margret\desktop\customr_orders";

        sourcePath = Directory.GetFiles(source);
        destPath = Directory.GetFiles(destination);

        DateTime twentyFourHoursAgo = DateTime.Now.AddHours(-24);

        foreach (string file in sourcePath)
        {
            if (file.EndsWith(".txt"))
            {
                FileInfo f = new FileInfo(file);
                if (f.LastWriteTime > twentyFourHoursAgo)
                {
                    string fileName = Path.GetFileName(file);
                    string destinationPath = Path.Combine(destination, fileName);
                    File.Move(file, destinationPath);
                   Console.WriteLine(" {0} was moved to {0} ", file, destinationPath);

                }
            }
        }
    }

    static void Main(string[] args)
    {
        ConsoleKeyInfo info;
        do
        {
            Console.WriteLine(" Press a key to start file copy process, press x to quit.");
            Console.WriteLine();
            while (Console.KeyAvailable == false)

                FileCheck(@"c:\users\margret\desktop\customer", @"c:\users\margret\desktop\customer_orders");
                info = (Console.ReadKey(true));
                Console.Write("You pressed {0}. ", info.Key);
        }

        while (info.Key != ConsoleKey.X);
       
            Console.ReadLine();
        }      
    }
        
     


      
    



