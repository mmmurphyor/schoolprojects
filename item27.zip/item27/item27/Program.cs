﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class item27
{



    public class FileCheck
    {
        //need to move the copy and check here and call from main
    }

    static void Main(string[] args)
    {
        /* ConsoleKeyInfo info;
         Console.WriteLine("Press enter to start file copy process");
          info = (Console.ReadKey());
          char info2 = Convert.ToChar(info);
         // if (info2 == (char)13)


         //while loop if key isn't enter start over

        FileCheck fc = new FileCheck();
 */
        string sourcePath = @"c:\users\margret\desktop\customer\";
        string destinationPath = @"c:\users\margret\desktop\customr_orders";
        
        var dir = new DirectoryInfo(@"c:\users\margret\desktop\customer\"); //object

        FileInfo[] files = dir.GetFiles("*.txt");
        DateTime twentyFourHoursAgo = DateTime.Now.AddHours(-24);
        foreach (System.IO.FileInfo file in files)
        {
           
            if (file.LastWriteTime > twentyFourHoursAgo) 
            Console.WriteLine( file.Name, file.LastWriteTime);
            foreach(var s in files)
            {
                File.Copy(sourcePath, destinationPath);
            }
           // foreach (var srcPath in Directory.GetFiles(sourcePath))
             //   File.Copy(srcPath, srcPath.Replace(sourcePath, destinationPath), true);
        }

        // string[] filePaths = Directory.GetFiles(@"c:\users\margret\desktop\customer", "*.txt", SearchOption.AllDirectories);
        Console.ReadLine();
        
    }
}        
     


      
    



