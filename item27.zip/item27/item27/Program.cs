﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class item27
{



    public class FileCheck
    {
        //need to move the copy and check here and call from main
    }

    static void Main(string[] args)
    {
        /* ConsoleKeyInfo info;
         Console.WriteLine("Press enter to start file copy process");
          info = (Console.ReadKey());
          char info2 = Convert.ToChar(info);
         // if (info2 == (char)13)


         //while loop if key isn't enter start over

        FileCheck fc = new FileCheck();
 */
       
        var dir = new DirectoryInfo(@"c:\users\margret\desktop\customer\"); //object

        FileInfo[] files = dir.GetFiles("*.txt");
        foreach (System.IO.FileInfo stuff in files)
        {
            if(stuff.LastWriteTime < DateTime.Now) ///need to fix this so last write time is older than 24 hours.
            Console.WriteLine( stuff.LastWriteTime);
        }

        // string[] filePaths = Directory.GetFiles(@"c:\users\margret\desktop\customer", "*.txt", SearchOption.AllDirectories);
        Console.ReadLine();

    }
}        
     


      
    



