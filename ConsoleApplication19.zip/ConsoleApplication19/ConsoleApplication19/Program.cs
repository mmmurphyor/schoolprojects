﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    //strings are immutable, string builder is mutable, which makes it a lot more efficient when working with manipulating strings especially large
    //numbers of them because it doesn't have to recreate the string over and over each time it iterates through.

    static void Main(string[] args)
    {
        //example: concatenation with string  vs stringbuilder
        string result = "";
        string[] str = new string[] { "one", "two", "three", "four", "five" };
        foreach (String s in str)
        {
            result = result + s;
            string strResult = string.Join(" ", str);
            Console.WriteLine(strResult);
        }
        Console.WriteLine();
        //vs

        StringBuilder sb = new StringBuilder();
        foreach (String s in str)
        {
            sb.Append(s);
           
        }
        string result2 = sb.ToString();
        string strResult2 = string.Join(" ", str);

        Console.WriteLine(strResult2);

        Console.ReadKey();
    }//string had to go through array 5 times, stringbuilder once.
}