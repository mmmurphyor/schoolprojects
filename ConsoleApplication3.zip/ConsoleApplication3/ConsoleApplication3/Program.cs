﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Margret Murphy, here are the first three examples from c# drill item23
namespace ConsoleApplication3
{
   class Examples
   {
      static void Main(string[] args)
      {
         Console.WriteLine("Method Overloading");
         Console.WriteLine("SquareRoot of integer 7 is {0}", Squareroot(7));
         Console.WriteLine("SquareRoot of double 7.5 is {0}", Squareroot(7.5));
         Console.WriteLine();

         Console.WriteLine("Method Overriding");
         BaseClass test;
         test = new BaseClass();
         test.TestClass();
         test = new DerivedClass();
         test.TestClass();
         Console.WriteLine();

         PrivateTest pInt = new PrivateTest();
         string msg = pInt.TestPhrase();
         Console.WriteLine(msg);
         PrivateTest pub = new PrivateTest();
         Console.WriteLine(pub.testPhrase2);
         Console.WriteLine();

         Console.ReadKey();
      }//method overloading
      public static int Squareroot(int value)
      {
         Console.WriteLine("Calling Squareroot with int argument");
         return Convert.ToInt32(Math.Sqrt(value));
      }
      public static double Squareroot(double value)
      {
         Console.WriteLine("Calling Squareroot with double argument");
         return Math.Sqrt(value);

      }//method overriding, and derived class example
      class BaseClass
      {
         public virtual void TestClass()
         {
            Console.WriteLine("This is the base class.");
         }
      }
      class DerivedClass : BaseClass
      {
         public override void TestClass()
         {
            Console.WriteLine("This is the derived class.");
         }
      }
      

      //public and private access modifier
      class PrivateTest
      {  
         private string testPhrase = "A private string with a public accessor, only way to use it outside it's class";
         public string testPhrase2 = "A public string can be accessed outside the class directly";
         public string TestPhrase() //private string needed an accessor
         {
            return testPhrase;
         }
      }
   }
}