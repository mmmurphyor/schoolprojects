﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//protected access modifier
class ProtectedBase
{
   protected string phrase;
}
//struct example
struct mail
{
   public string firstName;
   public string lastName;
   public string address;
   public string city;
   public string state;
   public string zip;
}
//sealed class example
public sealed class CantInheritMe
{
   public string sealedString = ("Since this class is sealed it can't be inherited from.");
}

//protected access modifier
class ProtectedDerived :ProtectedBase
{
   static void Main(string[] args)
   {
      ProtectedDerived ptest = new ProtectedDerived();
      ptest.phrase = "This has direct access to protected string.";
      Console.WriteLine(ptest.phrase);
      Console.WriteLine();

      mail add1 = new mail();
      add1.firstName = "Margret";
      add1.lastName = "Murphy";
      add1.address = "4884 Liberty St S, #153";
      add1.city = "Salem";
      add1.state = "OR";
      add1.zip = "97306";
      Console.WriteLine("Address:\n{0} {1}\n{2}\n{3}, {4}  {5}", add1.firstName, add1.lastName, add1.address, add1.city, add1.state, add1.zip);
      Console.WriteLine();

      CantInheritMe sayit = new CantInheritMe();
      Console.WriteLine(sayit.sealedString);
      Console.WriteLine();

      Console.ReadLine();
   }
   
}   
